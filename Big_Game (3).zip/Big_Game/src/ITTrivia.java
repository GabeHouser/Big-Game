public class ITTrivia {
    public static void play(){

    }
}
