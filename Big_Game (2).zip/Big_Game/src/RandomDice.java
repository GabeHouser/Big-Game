import java.awt.event.KeyAdapter;
import java.util.Random;
import java.util.Scanner;
import java.awt.event.KeyEvent;
public class RandomDice {
    public static void play(){
        //start new game
        Scanner in=new Scanner(System.in);
        boolean out = true;
        //while loop for inputs on how many players
        while(out){
            System.out.println("Would you like to play (1) player or (2)");
            String input =in.nextLine();
            //accept input to be tested if not 1 or 2 ask for another input
            if(input.equals("1")){
                OnePlayer(in);
            }
            else if(input.equals("2")){
                TwoPlayer(in);
            }
            else{
                System.out.println("Please enter 1 or 2");
            }
            System.out.println("would you like to play again (y/n)");
            input =in.nextLine();
            if(input.equalsIgnoreCase("y")){}
            if(input.equalsIgnoreCase("n")){
                Menu.menu();
            }
        }

    }
    public static void OnePlayer(Scanner in){
        Random rand = new Random();
        //intitialize health
        int playerOneHealth = 10;
        int playerTwoHealth = 10;
        int i = 1;
        boolean goesFirst = true;
        while(goesFirst){
            int playerOneRoll = rand.nextInt(5)+1;
            int playerTwoRoll = rand.nextInt(5)+1;
            System.out.println("player one rolled "+playerOneRoll);
            System.out.println("NPC rolled "+playerTwoRoll);
            if(playerOneRoll<playerTwoRoll && playerOneRoll!=playerTwoRoll){
                i++;
                System.out.println("NPC goes first!");
                goesFirst = false;
            }
            if(playerTwoRoll<playerOneRoll && playerOneRoll!=playerTwoRoll){
                System.out.println("player one goes first!");
                goesFirst = false;
            }
        }
        //while both players have not zero health keep playing
        while(playerOneHealth != 0 && playerTwoHealth != 0){
            //if counting variable is odd then player ones turn
            if(i%2 == 1){
                //let player know what to do
                System.out.println("player one's turn");
                System.out.println("Press enter to roll");
                //get input
                String input = in.nextLine();
                //get random number from between 1-6
                int intrandom = rand.nextInt(5)+1;
                //tell playing how much damage they did
                System.out.println("You rolled a " + String.valueOf(intrandom));
                //check if player health is exactly zero if it is game ends and player 1 wins else tell player they missed
                if((playerTwoHealth-intrandom) >= 0){
                    playerTwoHealth=playerTwoHealth-intrandom;
                }
                else{
                    System.out.println("You over-swung and missed");
                }
                if(playerTwoHealth==0){
                    System.out.println("Player one won!!");
                    break;
                }
                //end of turn tell player health of both players
                System.out.println("Player One Health: " + playerOneHealth);
                System.out.println("NPC Health: " + playerTwoHealth + "\n");
                i++;

            }

            //if counting variable is even it is players twos turn
            if(i%2 == 0){
                System.out.println("NPC's turn");
                //creates a random number from 1 to 6
                int intrandom = rand.nextInt(5)+1;
                System.out.println("You rolled a " + String.valueOf(intrandom));
                //change player one health based on roll
                if((playerOneHealth-intrandom) >= 0){
                    playerOneHealth=playerOneHealth-intrandom;
                }
                else{
                    System.out.println("You over-swung and missed");
                }
                if(playerOneHealth==0){
                    System.out.println("NPC won!!");
                    break;
                }
                System.out.println("Player One Health: " + playerOneHealth);
                System.out.println("NPC Health: " + playerTwoHealth + "\n");
                i++;
            }
        }
    }
    public static void TwoPlayer(Scanner in){
        Random rand = new Random();
        int playerOneHealth = 10;
        int playerTwoHealth = 10;
        int i = 1;
        boolean goesFirst = true;
        while(goesFirst){
            int playerOneRoll = rand.nextInt(5)+1;
            int playerTwoRoll = rand.nextInt(5)+1;
            System.out.println("player one rolled "+playerOneRoll);
            System.out.println("player two rolled "+playerTwoRoll);
            if(playerOneRoll<playerTwoRoll && playerOneRoll!=playerTwoRoll){
                i++;
                System.out.println("player two goes first!");
                goesFirst = false;
            }
            if(playerTwoRoll<playerOneRoll && playerOneRoll!=playerTwoRoll){
                System.out.println("player one goes first!");
                goesFirst = false;
            }
        }

        while(playerOneHealth != 0 && playerTwoHealth != 0){
            //if counting variable is odd then player ones turn
            if(i%2 == 1){
                //let player know what to do
                System.out.println("player one's turn");
                System.out.println("Press enter to roll");
                //get input
                String input = in.nextLine();
                //get random number from between 1-6
                int intrandom = rand.nextInt(5)+1;
                //tell playing how much damage they did
                System.out.println("You rolled a " + String.valueOf(intrandom));
                //check if player health is exactly zero if it is game ends and player 1 wins else tell player they missed
                if((playerTwoHealth-intrandom) >= 0){
                    playerTwoHealth=playerTwoHealth-intrandom;
                }
                else{
                    System.out.println("You over-swung and missed");
                }
                //end of turn tell player health of both players
                System.out.println("Player One Health: " + playerOneHealth);
                System.out.println("Player Two Health: " + playerTwoHealth);
                i++;
                if(playerTwoHealth==0){
                    System.out.println("Player one won!!");
                    break;
                }
            }
            if(i%2 == 0){
                //let player know what to do
                System.out.println("player two's turn");
                System.out.println("Press enter to roll");
                //get input
                String input = in.nextLine();
                //get random number from between 1-6
                int intrandom = rand.nextInt(5)+1;
                //tell playing how much damage they did
                System.out.println("You rolled a " + String.valueOf(intrandom));
                //check if player health is exactly zero if it is game ends and player 1 wins else tell player they missed
                if((playerOneHealth-intrandom) >= 0){
                    playerOneHealth=playerOneHealth-intrandom;
                }
                else{
                    System.out.println("You over-swung and missed");
                }
                //end of turn tell player health of both players
                System.out.println("Player One Health: " + playerOneHealth);
                System.out.println("Player Two Health: " + playerTwoHealth);
                i++;
                if(playerOneHealth==0){
                    System.out.println("Player two won!!");
                    break;
                }
            }
        }


    }
}
