public class WorldTraveler {
    public static void play(){

    }
}
