public class WhoAmI {
    public static void play(){

    }
}
