public class RaceForRiches {
    public static void play(){

    }
}
