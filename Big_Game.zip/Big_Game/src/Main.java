import java.util.Scanner;
import java.util.Random;

import static java.lang.Integer.parseInt;

public class Main {
    public static void main(String[] args) {
        //Make menu system where you can open menu at any point to pause, resume or quit out
        Menu.menu();

    }
}